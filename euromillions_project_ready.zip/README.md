# 🔮 Prédictions Euromillions

Un projet open-source complet pour analyser les tirages passés de l’EuroMillions, générer des grilles prédictives et effectuer des simulations de performances à l’aide d’un backtest par année.

## 📁 Structure du projet

- `data/` : Fichiers CSV contenant l’historique des tirages
- `results/` : Grilles générées et états "quantiques"
- `logs/` : Fichiers de backtest et suivi
- `check_env.py` : Script de validation de l’environnement (vérifie les fichiers essentiels et répare si nécessaire)
- `fusion_euromillions.py`, `fix_csv_header.py`, `clean_tirage_csv.py` : Scripts de préparation du dataset
- `predictor.py`, `quantum_preparation.py`, `backtest.py` : Algorithmes de prédiction
- `run_all.py` : Lance toute la chaîne d’analyse en 1 commande

## ⚙️ Prérequis

- Python 3.8+
- pandas

```bash
pip install pandas
```

## ✅ Vérification de l’environnement

Avant toute exécution :

```bash
python3 check_env.py
```

Il vérifie :
- la structure des dossiers (`data`, `logs`, `results`)
- la présence des scripts essentiels
- l’intégrité du fichier CSV `tirages_euromillion.csv`

## 🧼 Nettoyage des données

Vous pouvez régénérer le fichier CSV propre à tout moment avec :

```bash
python3 fusion_euromillions.py
python3 fix_csv_header.py
python3 clean_tirage_csv.py
```

## 🔮 Pour générer une prédiction :

```bash
python3 predictor.py
```

Cela crée :
- `results/grilles_prediction.csv`

> ⚠️ **Important :** Assurez-vous que le fichier `tirages_euromillion.csv` contient la **dernière date à jour** (ex: 2025-05-28) pour que la prédiction tienne compte des derniers tirages.  
> Utilisez `check_env.py` pour corriger si besoin.

## 🧠 Génération quantique (pondération probabiliste)

```bash
python3 quantum_preparation.py
```

Crée `results/quantum_states.csv` à partir des grilles précédentes.

## 📊 Lancer un backtest

```bash
python3 backtest.py
```

Les résultats du backtest sont enregistrés dans `logs/backtest_2022.csv`.

## 🚀 Tout exécuter automatiquement

```bash
python3 run_all.py
```

## 🎓 Auteur

Ce projet est maintenu sous le pseudo **ABlÿX**.

---

Made with ❤️ and curiosity.
